from django.shortcuts import render

from . models import Contact

# Create your views here.\

def home(request):
    return render(request, 'home.html')

def books(request):
    return render(request, 'books.html')

def contact(request):
    if request.method == "POST":
        firstName = request.POST['firstName']
        lastName = request.POST['lastName']
        email = request.POST['email']
        phone = request.POST['phone']
        message = request.POST['message']

        Contact(firstName=firstName, lastName=lastName, email=email, phone=phone, message=message).save()
    return render(request, 'contact.html')

def about(request):
    return render(request, 'about.html')

